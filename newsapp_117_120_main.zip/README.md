# newsapp-177_120-flutter
Aplikasi berita dinamis dengan menggunakan api dari https://newsapi.org/ yang dibangun menggunakan flutter.

# RUN PROGRAM
```
flutter pub get
flutter run
```
