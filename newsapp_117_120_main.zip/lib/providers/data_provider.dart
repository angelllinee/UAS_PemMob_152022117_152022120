import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:absolute_news/widgets/big_item_widget.dart';
import 'package:absolute_news/widgets/small_item_widget.dart';

class DataProvider extends ChangeNotifier {
  List _data = [];
  List get data => _data;
  set setData(val) {
    _data = val;
    notifyListeners();
  }

  List _dataPencarian = [];
  List get dataPencarian => _dataPencarian;
  set setDataPencarian(val) {
    _dataPencarian = val;
    notifyListeners();
  }

  TextEditingController _search = TextEditingController();
  TextEditingController get search => _search;
  set setSearch(val) {
    _search = val;
    notifyListeners();
  }

  bool _isFetchError = false;
  bool get isFetchError => _isFetchError;
  set setIsFetchError(val) {
    _isFetchError = val;
    notifyListeners();
  }

  Future fecthData(String category, String page) async {
    _data.clear();

    try {
      await http
          .get(Uri.parse(
            'https://newsapi.org/v2/top-headlines?country=us&category=$category&page=$page&apiKey=d50d09cacead4fe8996ac149dbfeacb6',
          ))
          .then(
            (response) => _data = json.decode("[" + response.body + "]"),
          );
    } catch (_) {
      try {
        await http
            .get(Uri.parse(
              'https://newsapi.org/v2/top-headlines?country=us&category=$category&page=$page&apiKey=d50d09cacead4fe8996ac149dbfeacb6',
            ))
            .then(
              (response) => _data = json.decode("[" + response.body + "]"),
            );
      } catch (_) {
        try {
          await http
              .get(Uri.parse(
                'https://newsapi.org/v2/top-headlines?country=us&category=$category&page=$page&apiKey=d50d09cacead4fe8996ac149dbfeacb6',
              ))
              .then(
                (response) => _data = json.decode("[" + response.body + "]"),
              );
        } catch (_) {
          try {
            await http
                .get(Uri.parse(
                  'https://newsapi.org/v2/top-headlines?country=us&category=$category&page=$page&apiKey=d50d09cacead4fe8996ac149dbfeacb6',
                ))
                .then(
                  (response) => _data = json.decode("[" + response.body + "]"),
                );
          } catch (_) {
            try {
              await http
                  .get(Uri.parse(
                    'https://newsapi.org/v2/top-headlines?country=us&category=$category&page=$page&apiKey=d50d09cacead4fe8996ac149dbfeacb6',
                  ))
                  .then(
                    (response) =>
                        _data = json.decode("[" + response.body + "]"),
                  );
            } catch (_) {
              setIsFetchError = true;
            }
          }
        }
      }
    }

    notifyListeners();
  }

  Future fecthDataPencarian(String keyword) async {
    _dataPencarian.clear();

    try {
      await http
          .get(Uri.parse(
            'https://newsapi.org/v2/everything?q=$keyword&apiKey=d50d09cacead4fe8996ac149dbfeacb6',
          ))
          .then(
            (response) =>
                _dataPencarian = json.decode("[" + response.body + "]"),
          );
    } catch (_) {
      try {
        await http
            .get(Uri.parse(
              'https://newsapi.org/v2/everything?q=$keyword&apiKey=d50d09cacead4fe8996ac149dbfeacb6',
            ))
            .then(
              (response) =>
                  _dataPencarian = json.decode("[" + response.body + "]"),
            );
      } catch (_) {
        try {
          await http
              .get(Uri.parse(
                'https://newsapi.org/v2/everything?q=$keyword&apiKey=d50d09cacead4fe8996ac149dbfeacb6',
              ))
              .then(
                (response) =>
                    _dataPencarian = json.decode("[" + response.body + "]"),
              );
        } catch (_) {
          try {
            await http
                .get(Uri.parse(
                  'https://newsapi.org/v2/everything?q=$keyword&apiKey=d50d09cacead4fe8996ac149dbfeacb6',
                ))
                .then(
                  (response) =>
                      _dataPencarian = json.decode("[" + response.body + "]"),
                );
          } catch (_) {
            try {
              await http
                  .get(Uri.parse(
                    'https://newsapi.org/v2/everything?q=$keyword&apiKey=d50d09cacead4fe8996ac149dbfeacb6',
                  ))
                  .then(
                    (response) =>
                        _dataPencarian = json.decode("[" + response.body + "]"),
                  );
            } catch (_) {
              setIsFetchError = true;
            }
          }
        }
      }
    }

    notifyListeners();
  }

  smallItemDetail(bool isSearch) {
    return List.generate(
        isSearch == true ? dataPencarian[0]['articles'].length : 20, (index) {
      var source = isSearch == true
          ? dataPencarian[0]['articles'][index]['source']['name']
          : data[0]['articles'][index]['source']['name'];
      var title = isSearch == true
          ? dataPencarian[0]['articles'][index]['title']
          : data[0]['articles'][index]['title'];
      var author = isSearch == true
          ? dataPencarian[0]['articles'][index]['author']
          : data[0]['articles'][index]['author'];
      var date = isSearch == true
          ? dataPencarian[0]['articles'][index]['publishedAt']
          : data[0]['articles'][index]['publishedAt'];
      var image = isSearch == true
          ? dataPencarian[0]['articles'][index]['urlToImage']
          : data[0]['articles'][index]['urlToImage'];
      var content = isSearch == true
          ? dataPencarian[0]['articles'][index]['content']
          : data[0]['articles'][index]['content'];
      var url = isSearch == true
          ? dataPencarian[0]['articles'][index]['url']
          : data[0]['articles'][index]['url'];

      return isSearch == true
          ? SmallItemWidget(
              source: source ?? 'null',
              title: title ?? 'null',
              author: author ?? 'null',
              date: date ?? 'null',
              image: image ??
                  'https://functionalsoftware.net/wp-content/uploads/2015/09/null-Verboten-900x550.png',
              content: content ?? 'null',
              url: url ?? 'null',
            )
          : index >= 10
              ? SmallItemWidget(
                  source: source ?? 'null',
                  title: title ?? 'null',
                  author: author ?? 'null',
                  date: date ?? 'null',
                  image: image ??
                      'https://functionalsoftware.net/wp-content/uploads/2015/09/null-Verboten-900x550.png',
                  content: content ?? 'null',
                  url: url ?? 'null',
                )
              : Container();
    });
  }

  bigItemDetail() {
    return List.generate(10, (index) {
      var source = data[0]['articles'][index]['source']['name'];
      var title = data[0]['articles'][index]['title'];
      var author = data[0]['articles'][index]['author'];
      var date = data[0]['articles'][index]['publishedAt'];
      var image = data[0]['articles'][index]['urlToImage'];
      var content = data[0]['articles'][index]['content'];
      var url = data[0]['articles'][index]['url'];
      var description = data[0]['articles'][index]['description'];

      return BigItemWidget(
        source: source ?? 'null',
        title: title ?? 'null',
        author: author ?? 'null',
        date: date ?? 'null',
        image: image ??
            'https://functionalsoftware.net/wp-content/uploads/2015/09/null-Verboten-900x550.png',
        content: content ?? 'null',
        url: url ?? 'null',
        desc: description ?? 'null',
      );
    });
  }
}
