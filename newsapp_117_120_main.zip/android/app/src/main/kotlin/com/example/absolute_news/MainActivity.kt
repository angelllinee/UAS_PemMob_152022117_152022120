package com.example.absolute_news

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
