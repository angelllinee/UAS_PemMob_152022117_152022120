package com.example.absolute_news_flutter_main

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
